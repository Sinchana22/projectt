package com.sreesha.in.service;

import java.util.List;

import com.sreesha.in.model.Donation;

public interface ServiceInterface {
	
	public Integer saveDonation(Donation donation);
	
	public List<Donation> getAllDonation();
	

}
