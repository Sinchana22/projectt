package com.sreesha.in.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sreesha.in.model.Donation;

public interface DonateRepository extends JpaRepository<Donation, Integer> {

}
