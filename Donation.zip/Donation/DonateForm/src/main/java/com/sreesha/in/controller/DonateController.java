package com.sreesha.in.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sreesha.in.model.Donation;
import com.sreesha.in.service.ServiceInterface;

@RestController
@RequestMapping("/rest/donation")
@CrossOrigin(origins = "http://localhost:4200")
public class DonateController {
	
	@Autowired
	private ServiceInterface si;
	
	@PostMapping("/add")
	public ResponseEntity<String> saveDonation(@RequestBody Donation donation) {
		try {
			Integer id = si.saveDonation(donation);
			String msg = "Donor with id: "+id+" created successfully";
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Unable to create!", HttpStatus.INTERNAL_SERVER_ERROR);
		}	
	}
}
