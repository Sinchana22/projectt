package com.sreesha.in.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreesha.in.model.Donation;
import com.sreesha.in.repo.DonateRepository;

@Service
public class ServiceInterfaceImplementation implements ServiceInterface {
	
	@Autowired
	private DonateRepository repo;

	public Integer saveDonation(Donation donation) {
		donation = repo.save(donation);
		return donation.getId();
	}

	public List<Donation> getAllDonation() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
}
