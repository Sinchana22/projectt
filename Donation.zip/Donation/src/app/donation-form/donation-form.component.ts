import { Component, OnInit } from '@angular/core';
import { DonationService } from './../donation.service';
import { Donation } from '../donation';
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-donation',
  templateUrl: './donation-form.component.html',
  styleUrls: ['./donation-form.component.css']
})

export class DonationFormComponent implements OnInit {
  // form backing object
  donation!:Donation;
  // message to ui
  message!: string;
  // inject service class
  constructor(private service: DonationService, private http: HttpClientModule) { }
  ngOnInit(): void {
    // when page is loaded clear form data
    this.donation = new Donation();
    
  }
  
  // tslint:disable-next-line: typedef
  createDonation() {
    this.service.createDonation(this.donation)
    .subscribe(data => {
      this.message = data; // read message
      this.donation = new Donation(); 
      console.log(this.message);// clear form
    }, error => {
      console.log(error);
    });
  }
}

