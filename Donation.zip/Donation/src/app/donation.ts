export class Donation {
    public name!:string;
    public email!: string;
    public amount!: number;
}