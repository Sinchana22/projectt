import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Donation } from './donation';


@Injectable({
  providedIn: 'root'
})
export class DonationService {
    
  private basePath = 'http://localhost:8090/rest/donation';

  constructor(private http: HttpClient) { 
      
  }

  getAllDonation(): Observable<Donation[]> {
    return this.http.get<Donation[]>(`${this.basePath}/view`);
  }
  

  createDonation(donation: Donation): Observable<any> {
    return this.http.post(`${this.basePath}/add`, donation, {responseType: 'text'});
  }

}